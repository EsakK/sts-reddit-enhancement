System.import('main').then(null, console.error.bind(console)); 
